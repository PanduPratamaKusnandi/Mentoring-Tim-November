from flask import Flask, request, jsonify
import pickle
import numpy as np
import os

# Inisialisasi aplikasi Flask
app = Flask(__name__)

# Memuat model machine learning dan scaler yang telah disimpan
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

with open('scaler.pkl', 'rb') as f:
    scaler = pickle.load(f)

# Daftar kelas/karir yang digunakan dalam model
class_names = [
    'Pengacara', 'Dokter', 'Pejabat Pemerintah', 'Artis', 'Tidak Dikenal',
    'Software Engineer', 'Guru', 'Pengusaha', 'Ilmuwan',
    'Bankir', 'Penulis', 'Akutansi', 'Designer',
    'Construction Engineer', 'Game Developer', 'Investor Saham',
    'Real Estate Developer'
]

# Endpoint untuk melakukan prediksi
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Mengambil data input dari request JSON
        data = request.get_json()

        # Mengambil dan memproses fitur dari data input
        gender = 1 if data['gender'] == 'Male' else 0
        absence_days = int(data['absence_days'])
        study_hours = float(data['study_hours'])
        part_time = 1 if data['part_time'] == 'Yes' else 0
        extracurricular = 1 if data['extracurricular'] == 'Yes' else 0
        math = float(data['math'])
        history = float(data['history'])
        physics = float(data['physics'])
        chemistry = float(data['chemistry'])
        biology = float(data['biology'])
        english = float(data['english'])
        geography = float(data['geography'])

        # Menghitung total skor dan rata-rata skor
        total_score = math + history + physics + chemistry + biology + english + geography
        average_score = total_score / 7

        # Menggabungkan semua fitur menjadi array yang akan digunakan untuk prediksi
        features = np.array([[gender, absence_days, study_hours, part_time, extracurricular,
                              math, history, physics, chemistry, biology, english, geography,
                              total_score, average_score]])
        
        # Melakukan normalisasi fitur menggunakan scaler
        scaled_features = scaler.transform(features)

        # Memprediksi probabilitas kelas dengan model
        probabilities = model.predict_proba(scaled_features)

        # Mengambil 3 kelas teratas berdasarkan probabilitas tertinggi
        top_classes_idx = np.argsort(-probabilities[0])[:3]
        career_probabilities = [
            {"Karir": class_names[idx], "Probalitas": round(probabilities[0][idx] * 100, 2)}
            for idx in top_classes_idx
        ]

        # Mengembalikan hasil prediksi dalam format JSON
        return jsonify({
            "Total Nilai": total_score,
            "Rata-Rata Nilai": average_score,
            "Probalitas Karir": career_probabilities
        })
    
    except Exception as e:
        # Menangani error dan mengembalikan pesan error dalam format JSON
        return jsonify({"error": str(e)})

# Menjalankan aplikasi Flask
if __name__ == '__main__':
    # Menjalankan aplikasi Flask pada mode debug untuk pengembangan
    app.run(debug=True)
